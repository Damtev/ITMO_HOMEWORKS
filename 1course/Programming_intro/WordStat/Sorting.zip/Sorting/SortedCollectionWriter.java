package Sorting;

import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.util.TreeMap;
import java.util.Map.Entry;

public class SortedCollectionWriter {
    public static void main(String ...args) {
        try {
            TreeMap<String, Integer> my�ollection = new SortedCollectionMaker().getSortedCollection(args[0]);                                                    
            if (args.length > 1) {
                BufferedWriter writer = new BufferedWriter(new FileWriter(args[1]));        
                for (Entry<String, Integer> quontity_word : my�ollection.entrySet()) {
                    writer.write(quontity_word.getKey() + " - ");
                    writer.write(quontity_word.getValue().toString());
                    writer.newLine();
                }        
                writer.close();                                      
            } else {
                for (Entry<String, Integer> quontity_word : my�ollection.entrySet()) {
                    System.out.print(quontity_word.getKey() + " - ");
                    System.out.println(quontity_word.getValue());                  
                }                
            }
        } catch(ArrayIndexOutOfBoundsException e) {
            System.err.println("put the existe InputFileName into the CommandLine");
        } catch(IOException e) {
            System.err.print(e.getMessage());
        }
    }
}