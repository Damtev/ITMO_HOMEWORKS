package Sorting;

import java.io.FileReader;
import java.io.IOException;
import java.util.TreeMap;
import java.util.Scanner;
import java.util.Comparator;
import java.util.MissingResourceException;
import java.util.regex.PatternSyntaxException;
import java.text.ParseException;
import java.text.Collator;
import static java.util.ResourceBundle.getBundle;

public class SortedCollectionMaker {
	private Collator ruCollator = Collator.getInstance();
	
	public SortedCollectionMaker() {
		ruCollator.setStrength(Collator.PRIMARY);				
	}
	                                          
    private TreeMap<String, Integer> list = new TreeMap<String, Integer>(new Comparator<String>() {
                                                public int compare(String wort1, String wort2) {                                               		                                                	                                                		
                                                    return ruCollator.compare(wort1, wort2);
                                                }
                                            });
                                                                                                     
    public TreeMap<String, Integer> getSortedCollection(String fileName) throws IOException {      
        Scanner scan = new Scanner(new FileReader(fileName));       
        try {
            scan.useDelimiter(getBundle("Delimiters").getString("DELIMITER"));
            while (scan.hasNext()) { 
                String newWort = scan.next();                                                                   
                if (!list.containsKey(newWort)) {                
                    list.put(newWort, 1);                
                } else {
                	list.put(newWort, list.get(newWort) + 1);
                }                                                                                               
            } // end of while 
            return list;                 
        } catch (MissingResourceException m) {
            throw new IOException("Wrong or missed property-file!");               
        } catch (PatternSyntaxException p) {
            throw new IOException("Wrong delimiters!");
        } finally {
            scan.close();
        }   
    }
}